const env=document.getElementById('envelope');const cover=document.getElementById('cover');const letter=document.getElementById('letter');
env.onclick=()=>{cover.style.display='none';letter.classList.remove('hidden');window.scrollTo(0,0);}
function closeLetter(){letter.classList.add('hidden');cover.style.display='block';}
